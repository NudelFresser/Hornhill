package application;

import java.text.ParseException;
import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.net.URL;

import java.util.ResourceBundle;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;

import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

public class SampleController implements Initializable {

	public static LocalDate myDate;
	@FXML
	private Label labelZeiterfassungTag;

	@FXML
	private Label labelZeiterfassungArbeitsbeginn;

	@FXML
	private Label labelZeiterfassungGesetzlichesmaximum;

	@FXML
	private Label labelZeiterfassungArbeitsende;

	@FXML
	private CheckBox checkboxZeiterfassungZusatzpause;

	@FXML
	private Label labelZeiterfassungZusatzpause;

	@FXML
	private TextField textfieldZeiterfassungArbeitsbeginn;

	@FXML
	private TextField textfieldZeiterfassungGesetzlichesmaximum;

	@FXML
	private TextField textfieldZeiterfassungArbeitsende;

	@FXML
	private TextField textfieldZeiterfassungZusatzpause;

	@FXML
//	private DatePicker datepickerZeiterfassungTag;
	private DatePicker birthdayDatePicker;

	@FXML
	private Button buttonZeiterfassungDaten�bernehmen;

	@FXML
	private Label labelEinstellungenAltesPasswort;

	@FXML
	private Label labelEinstellungenSprache;

	@FXML
	private Label labelEinstellungenWochenarbeitszeit;

	@FXML
	private Label labelEinstellungenErsteWarnstufe;

	@FXML
	private Label labelEinstellungenZweiteWarnstufe;

	@FXML
	private PasswordField passwortfiedEinstellungenAltesPasswort;

	@FXML
	private RadioButton radioButtonEinstellungDeutsch;

	@FXML
	private ToggleGroup Sprache;

	@FXML
	private RadioButton radioButtonEinstellungenEnglisch;

	@FXML
	private TextField textfieldEinstellungenErsteWarnstufe;

	@FXML
	private TextField textfieldEinstellungenZweiteWarnstufe;

	@FXML
	private Button buttonEinstellungenEinstellungen�bernehmen;

	@FXML
	private Label labelEinstellungenNeuesPasswort1;
	
    @FXML
    private Label labelKalenderMonat;

    @FXML
    private Label labelKalenderAmpelansicht;

    @FXML
    private Label labelKalenderQuartal;

    @FXML
    private Label labelKalenderJahr;

    @FXML
    private TextField textfieldKalenderQuartalsStunden;

    @FXML
    private TextField textfieldKalenderJahresStunden;

    @FXML
    private TextField textfieldKalenderMonatsStunden;

    @FXML
    private Circle circleAmpelansichtColorGreen;

    @FXML
    private Circle circleAmpelansichtColorYellow;

    @FXML
    private Circle circleAmpelansichtColorRed;

	@FXML
	private PasswordField passwortfiedEinstellungenNeuesPasswort1;

	@FXML
	private PasswordField passwortfiedEinstellungenNeuesPasswort2;

	@FXML
	private Label labelEinstellungenNeuesPasswort2;

	@FXML
	private ChoiceBox<String> choiceBoxEinstellungenWochenarbeitszeit;

	@FXML
	private Label labelWochenarbeitszeit;

	@FXML
	private TableView<person> tableViewKalenderKalenderansicht;

//	@FXML
//	private TableColumn<person, LocalDate> tablecolumnKalenderTag;

	@FXML
	private TableColumn<person, SimpleStringProperty> tablecolumnKalenderArbeitsbeginn;

	@FXML
	private TableColumn<person, SimpleStringProperty> tablecolumnKalenderArbeitsende;

	@FXML
	private TableColumn<person, SimpleStringProperty> tablecolumnKalenderZusatzpause;

	@FXML
	private TableColumn<person, SimpleStringProperty> tablecolumnKalenderGleitzeit;
     
    @FXML private TableColumn<person, LocalDate> birthdayColumn;

	private String[] stunden = { "30 Stunden", "35 Stunden", "40 Stunden" };

	@FXML
	void initialize() {
		assert labelZeiterfassungTag != null : "fx:id=\"labelZeiterfassungTag\" was not injected: check your FXML file 'Sample.fxml'.";
		assert labelZeiterfassungArbeitsbeginn != null : "fx:id=\"labelZeiterfassungArbeitsbeginn\" was not injected: check your FXML file 'Sample.fxml'.";
		assert labelZeiterfassungGesetzlichesmaximum != null : "fx:id=\"labelZeiterfassungGesetzlichesmaximum\" was not injected: check your FXML file 'Sample.fxml'.";
		assert labelZeiterfassungArbeitsende != null : "fx:id=\"labelZeiterfassungArbeitsende\" was not injected: check your FXML file 'Sample.fxml'.";
		assert checkboxZeiterfassungZusatzpause != null : "fx:id=\"checkboxZeiterfassungZusatzpause\" was not injected: check your FXML file 'Sample.fxml'.";
		assert labelZeiterfassungZusatzpause != null : "fx:id=\"labelZeiterfassungZusatzpause\" was not injected: check your FXML file 'Sample.fxml'.";
		assert textfieldZeiterfassungArbeitsbeginn != null : "fx:id=\"textfieldZeiterfassungArbeitsbeginn\" was not injected: check your FXML file 'Sample.fxml'.";
		assert textfieldZeiterfassungGesetzlichesmaximum != null : "fx:id=\"textfieldZeiterfassungGesetzlichesmaximum\" was not injected: check your FXML file 'Sample.fxml'.";
		assert textfieldZeiterfassungArbeitsende != null : "fx:id=\"textfieldZeiterfassungArbeitsende\" was not injected: check your FXML file 'Sample.fxml'.";
		assert textfieldZeiterfassungZusatzpause != null : "fx:id=\"textfieldZeiterfassungZusatzpause\" was not injected: check your FXML file 'Sample.fxml'.";
				assert birthdayDatePicker != null : "fx:id=\"datepickerZeiterfassungTag\" was not injected: check your FXML file 'Sample.fxml'.";

//		assert datepickerZeiterfassungTag != null : "fx:id=\"datepickerZeiterfassungTag\" was not injected: check your FXML file 'Sample.fxml'.";
		assert buttonZeiterfassungDaten�bernehmen != null : "fx:id=\"buttonZeiterfassungDaten�bernehmen\" was not injected: check your FXML file 'Sample.fxml'.";
		assert labelEinstellungenAltesPasswort != null : "fx:id=\"labelEinstellungenAltesPasswort\" was not injected: check your FXML file 'Sample.fxml'.";
		assert labelEinstellungenSprache != null : "fx:id=\"labelEinstellungenSprache\" was not injected: check your FXML file 'Sample.fxml'.";
		assert labelEinstellungenWochenarbeitszeit != null : "fx:id=\"labelEinstellungenWochenarbeitszeit\" was not injected: check your FXML file 'Sample.fxml'.";
		assert labelEinstellungenErsteWarnstufe != null : "fx:id=\"labelEinstellungenErsteWarnstufe\" was not injected: check your FXML file 'Sample.fxml'.";
		assert labelEinstellungenZweiteWarnstufe != null : "fx:id=\"labelEinstellungenZweiteWarnstufe\" was not injected: check your FXML file 'Sample.fxml'.";
		assert passwortfiedEinstellungenAltesPasswort != null : "fx:id=\"passwortfiedEinstellungenAltesPasswort\" was not injected: check your FXML file 'Sample.fxml'.";
		assert radioButtonEinstellungDeutsch != null : "fx:id=\"radioButtonEinstellungDeutsch\" was not injected: check your FXML file 'Sample.fxml'.";
		assert Sprache != null : "fx:id=\"Sprache\" was not injected: check your FXML file 'Sample.fxml'.";
		assert radioButtonEinstellungenEnglisch != null : "fx:id=\"radioButtonEinstellungenEnglisch\" was not injected: check your FXML file 'Sample.fxml'.";
		assert choiceBoxEinstellungenWochenarbeitszeit != null : "fx:id=\"comboboxEinstellungenWochenarbeitszeit\" was not injected: check your FXML file 'Sample.fxml'.";
		assert textfieldEinstellungenErsteWarnstufe != null : "fx:id=\"textfieldEinstellungenErsteWarnstufe\" was not injected: check your FXML file 'Sample.fxml'.";
		assert textfieldEinstellungenZweiteWarnstufe != null : "fx:id=\"textfieldEinstellungenZweiteWarnstufe\" was not injected: check your FXML file 'Sample.fxml'.";
		assert buttonEinstellungenEinstellungen�bernehmen != null : "fx:id=\"buttonEinstellungenEinstellungen�bernehmen\" was not injected: check your FXML file 'Sample.fxml'.";
		assert labelEinstellungenNeuesPasswort1 != null : "fx:id=\"labelEinstellungenNeuesPasswort1\" was not injected: check your FXML file 'Sample.fxml'.";
		assert passwortfiedEinstellungenNeuesPasswort1 != null : "fx:id=\"passwortfiedEinstellungenNeuesPasswort1\" was not injected: check your FXML file 'Sample.fxml'.";
		assert labelEinstellungenNeuesPasswort2 != null : "fx:id=\"labelEinstellungenNeuesPasswort2\" was not injected: check your FXML file 'Sample.fxml'.";
		assert passwortfiedEinstellungenNeuesPasswort2 != null : "fx:id=\"passwortfiedEinstellungenNeuesPasswort2\" was not injected: check your FXML file 'Sample.fxml'.";

	}

//	public void getDate(ActionEvent event) {
//
//		myDate = datepickerZeiterfassungTag.getValue();
//		String myFormattedDate = myDate.format(DateTimeFormatter.ofPattern("MMM-dd-yyyy"));
//
//	}

	public void newPersonButtonPushed() {
//    	LocalDate date = datepickerZeiterfassungTag.getValue();
//    	String arbeitsbeginn = textfieldZeiterfassungArbeitsbeginn.getText();
//    	String arbeitsende = textfieldZeiterfassungArbeitsende.getText();
//    	String zusatzpause =textfieldZeiterfassungZusatzpause.getText();
//		 LocalDate myDate = birthdayDatePicker.getValue();
//		
//		 DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
//		 LocalDate date = LocalDate.parse("14/10/2021", formatter);
		  
		person newPerson = new person(birthdayDatePicker.getValue(), textfieldZeiterfassungArbeitsbeginn.getText(),
				textfieldZeiterfassungArbeitsende.getText(), textfieldZeiterfassungZusatzpause.getText());

		// Get all the items from the table as a list, then add the new person to
		// the list
		tableViewKalenderKalenderansicht.getItems().add(newPerson);
	}

	public void mehrPause() throws ParseException {

		if (checkboxZeiterfassungZusatzpause.isSelected()) {
			labelZeiterfassungZusatzpause.setVisible(true);
			textfieldZeiterfassungZusatzpause.setVisible(true);
			circleAmpelansichtColorYellow.setFill(Color.DARKSLATEBLUE);
		

		} else {

			labelZeiterfassungZusatzpause.setVisible(false);
			textfieldZeiterfassungZusatzpause.setVisible(false);
			circleAmpelansichtColorYellow.setFill(Color.WHITE);

		}

	}

	public void getComboBox(ActionEvent event) {
		String s = choiceBoxEinstellungenWochenarbeitszeit.getValue();
		int wochenarbeitszeit = Integer.parseInt(s.substring(0, 2));
		System.out.println(wochenarbeitszeit);

		
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {

		choiceBoxEinstellungenWochenarbeitszeit.getItems().addAll(stunden);
		choiceBoxEinstellungenWochenarbeitszeit.setOnAction(this::getComboBox);
//		tablecolumnKalenderTag.setCellValueFactory(new PropertyValueFactory<person, SimpleStringProperty>("Tag"));
//		tablecolumnKalenderTag.setCellValueFactory(new PropertyValueFactory<person, LocalDate>("Tag"));
		birthdayColumn.setCellValueFactory(new PropertyValueFactory<person, LocalDate>("birthday"));
		tablecolumnKalenderArbeitsbeginn
				.setCellValueFactory(new PropertyValueFactory<person, SimpleStringProperty>("Arbeitsbeginn"));
		tablecolumnKalenderArbeitsende
				.setCellValueFactory(new PropertyValueFactory<person, SimpleStringProperty>("Arbeitsende"));
		tablecolumnKalenderZusatzpause
				.setCellValueFactory(new PropertyValueFactory<person, SimpleStringProperty>("Pause"));
		tablecolumnKalenderGleitzeit
				.setCellValueFactory(new PropertyValueFactory<person, SimpleStringProperty>("Gleitzeit"));

//        tableViewKalenderKalenderansicht.setItems();

		tableViewKalenderKalenderansicht.setEditable(false);
//	        tablecolumnKalenderArbeitsbeginn.setCellValueFactory(TextFieldTableCell.forTableColumn());
//	        tablecolumnKalenderArbeitsende.setCellFactory(TextFieldTableCell.forTableColumn());

		circleAmpelansichtColorYellow.setFill(Color.RED);
		textfieldZeiterfassungArbeitsbeginn.textProperty().addListener((observable, oldValue, newValue) -> {
			String s = textfieldZeiterfassungArbeitsbeginn.getText().replace(":", ".");
			if (textfieldZeiterfassungArbeitsbeginn.getText() == "") {
				textfieldZeiterfassungGesetzlichesmaximum.setText("");
			} else {

				Double d = Double.valueOf(s) + 8.0;
				s = String.valueOf(d).replace(".", ":");
				textfieldZeiterfassungGesetzlichesmaximum.setText(s);
			}
		});

	}

//    public ObservableList<person>  getPeople()
//    {
//        ObservableList<person> people = FXCollections.observableArrayList();
//        people.add(new person(LocalDate.of(2021,10,14), "07:45", "16:00", "01:00"));
//        
//        return people;
//    }

}
