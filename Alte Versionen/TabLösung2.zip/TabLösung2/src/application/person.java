package application;

import java.time.LocalDate;

import javafx.beans.property.SimpleStringProperty;

public class person {

	private LocalDate birthday;

	private SimpleStringProperty arbeitsbeginn, arbeitsende, pause;

	public person(LocalDate birthday, String arbeitsbeginn, String arbeitsende, String pause) {
		this.birthday = birthday;
//		this.arbeitstag = new SimpleStringProperty(arbeitstag);
		this.arbeitsbeginn = new SimpleStringProperty(arbeitsbeginn);
		this.arbeitsende = new SimpleStringProperty(arbeitsende);
		this.pause = new SimpleStringProperty(pause);

	}

//	public LocalDate getArbeitstag() {
//		return arbeitstag;
//	}

	public LocalDate getBirthday() {
		return birthday;
	}
//
//	public void setArbeitstag(LocalDate arbeitstag) {
//		this.arbeitstag = arbeitstag;
//	}

	public void setBirthday(LocalDate birthday) {
		this.birthday = birthday;
	}

	public String getArbeitsbeginn() {
		return arbeitsbeginn.get();
	}

	public void setArbeitsbeginn(SimpleStringProperty arbeitsbeginn) {
		this.arbeitsbeginn = arbeitsbeginn;
	}

	public String getArbeitsende() {
		return arbeitsende.get();
	}

	public void setArbeitsende(SimpleStringProperty arbeitsende) {
		this.arbeitsende = arbeitsende;
	}

	public String getPause() {
		return pause.get();
	}

	public void setPause(SimpleStringProperty pause) {
		this.pause = pause;
	}
//	public String getArbeitstag() {
//		return arbeitstag.get();
//	}
//
//	public void setArbeitstag(SimpleStringProperty arbeitstag) {
//		this.arbeitstag = arbeitstag;
//	}

}
