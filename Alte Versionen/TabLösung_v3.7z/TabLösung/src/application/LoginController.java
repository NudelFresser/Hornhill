package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoginController {

	@FXML
	private Label labelNutzername;

	@FXML
	private TextField textfieldNutzername;

	@FXML
	private Label labelPasswort;

	@FXML
	private PasswordField textfieldPasswort;

	@FXML
	void initialize() {
		assert labelNutzername != null : "fx:id=\"labelNutzername\" was not injected: check your FXML file 'Login.fxml'.";
		assert textfieldNutzername != null : "fx:id=\"textfieldNutzername\" was not injected: check your FXML file 'Login.fxml'.";
		assert labelPasswort != null : "fx:id=\"labelPasswort\" was not injected: check your FXML file 'Login.fxml'.";
		assert textfieldPasswort != null : "fx:id=\"textfieldPasswort\" was not injected: check your FXML file 'Login.fxml'.";
	}

	public void switchToZeiterfassung(ActionEvent event) throws IOException {

		UserConfig uc = new UserConfig();

		if(uc.login(textfieldNutzername.getText(), textfieldPasswort.getText())) {
			Parent tableView = FXMLLoader.load(getClass().getResource("Sample.fxml"));
			Scene tableViewscene = new Scene(tableView);
			Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
			window.setScene(tableViewscene);
			window.show();
		}
		else {
			textfieldNutzername.setText("");
			textfieldPasswort.setText("");

		}

	}

	public void switchToRegistration(ActionEvent event) throws IOException {

		Parent tableView = FXMLLoader.load(getClass().getResource("Registrierung.fxml"));
		Scene tableViewscene = new Scene(tableView);
		Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
		window.setScene(tableViewscene);
		window.show();
	}
}